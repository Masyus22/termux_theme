<h1 align="center">
  Termux Theme
</h1>
<p align="center">
<a href="#"><img title="Author by Sanz" src="https://img.shields.io/badge/Coded%20By-Sanz-orange?"></a>
<a href="#"><img title="Author by Sanz" src="https://img.shields.io/badge/Code%20-python3.9-blue?"></a>
<br>
<a href="https://github.com/Sxp-ID/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Sxp-ID?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Sxp-ID/termux-theme/stargazers/">
<img title="Stars" src="https://img.shields.io/github/stars/Sxp-ID/termux-theme?label=Stars&color=red&style=flat-square"></a>
<a href="https://github.com/Sxp-ID/termux-theme/network/members">
<img title="Forks" src="https://img.shields.io/github/forks/Sxp-ID/termux-theme?label=Forks&color=red&style=flat-square"></a>
<a href="https://github.com/Sxp-ID/termux-theme/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Sxp-ID/termux-style?label=Watchers&color=blue&style=flat-square"></a>
</br>
</p>

## How To It?
```python
$ cd termux-theme
$ bash install.sh
```

> Get Token [click here](https://bit.ly/TokenTermuxTheme)

![Gpp jelek yg penting bikinan sendiri yahaha ^.^](https://github.com/Sxp-ID/termux-theme/blob/main/.Tools%20Termux%20Theme%20by%20Sanz.png?raw=true)

## Support Me On
<b>- [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>- [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
<!-- Wih Bang jago klik raw pasti mau copas ya >_<
<!-- Jangan di copas donk anyink :v
